//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by msAllegTool.rc
//
#define IDC_BTCOLOR                     1002
#define IDC_SLSPEED                     1003
#define IDC_LGROUPS                     1004
#define IDC_LCVH                        1005
#define IDC_LMDL                        1006
#define IDD_AMTDLG                      1007
#define IDC_BTMDLTOOBJ                  1007
#define IDD_DLGLIGHT                    1008
#define IDC_BTOBJTOMDL                  1008
#define IDC_BTCVHTOOBJ                  1009
#define IDC_BTOBJTOCVH                  1010
#define IDC_LJOINTS                     1011
#define IDC_LPOS                        1012
#define IDC_LLIGHTS                     1013
#define IDC_TABFL                       1014
#define IDC_LFRAMES                     1015
#define IDC_BTPOSTOJ                    1016
#define IDC_BTJTOPOS                    1017
#define IDC_BTJTOLF                     1018
#define IDC_BTLFTOJ                     1019
#define IDC_BTHIDEMDL                   1020
#define IDC_BTHIDEGROUP                 1021
#define IDC_BTHIDECVH                   1022
#define IDC_BTADDPOS                    1023
#define IDC_BTSHOWMDL                   1024
#define IDC_BTSHOWGROUP                 1025
#define IDC_BTSHOWMDL2                  1026
#define IDC_BTSHOWCVH                   1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1001
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           1009
#endif
#endif
