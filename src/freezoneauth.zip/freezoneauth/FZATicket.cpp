// FZATicket.cpp : Implementation of CFZATicket

#include "stdafx.h"
#include "FZATicket.h"


// CFZATicket


STDMETHODIMP CFZATicket::Meth1(CHAR* p1, CHAR* p2)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CFZATicket::Meth2(CHAR* p1, CHAR* p2)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	return S_OK;
}
