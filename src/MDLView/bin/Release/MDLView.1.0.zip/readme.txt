MDLView 1.0.1176.13883 release

Requirement: 

	MDLView requires DirectX 9 and the .NET Framework.
	You can install the .NET framework via Windows Update (http://windowsupdate.microsoft.com).
	You can install DirectX 9 via http://www.microsoft.com/directx. 

	Note: DirectX 9 includes a component ("Managed DirectX 9") that is 
	dependent on the .net framework being installed. Therefore, it is 
	important that you install the .net framework 	first, and then install 
	DirectX 9.  If you have installed DirectX 9 before installing the 
	.net framework, you will need to re-run the DirectX 9 setup to ensure 
	that "Managed DirectX 9" is installed properly. Also, some DirectX 9 
	installation utilities do not include the Managed DirectX 9 
	component. The best means of obtaining the Managed DirectX 9 component 
	is to use the web setup at the link provided above.


Known problems:

	- selecting invalid/non 3D model file doesnt change the 3D view
	- dir/files lists sometimes get out of sync

Limitations:

	- only LOD 0 is handled for now

(2) 2003 Kirth Gersen