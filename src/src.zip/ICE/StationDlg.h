#pragma once


// CStationDlg dialog

class CStationDlg : public CDialog
{
	DECLARE_DYNAMIC(CStationDlg)

public:
	CStationDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CStationDlg();
	PtrCoreStationType pstation;
	CString sArtPath;
	CBMPMDLButton mdlbmp;
	CBMPMDLButton imdlbmp;
	CComboBox *cbtype;
// Dialog Data
	enum { IDD = IDD_STATIONDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	void OnClickedDecodesel(void);
	void OnClickedDecodeh(void);
	BOOL OnInitDialog(void);
	void OnClickedOk(void);
	void OnClickedCancel(void);
};
