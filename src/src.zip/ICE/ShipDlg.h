#pragma once


// CShipDlg dialog

class CShipDlg : public CDialog
{
	DECLARE_DYNAMIC(CShipDlg)

public:
	CShipDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CShipDlg();
	PtrCoreShip pship;
	PtrCore pcore;
	CString sArtPath;
	CBMPMDLButton mdlbmp;
	CBMPMDLButton mdlbmp2;
// Dialog Data
	enum { IDD = IDD_SHIPDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	void OnClickedDecodesel(void);
	void OnClickedDecodeh(void);
	BOOL OnInitDialog(void);
	void OnClickedOk(void);
	void OnClickedCancel(void);
	void OnClickedModeledit(void);
	void OnSelchangePartsel(void);
	void OnSelchangeWepsel(void);
//	afx_msg void OnBnClickedDlclear();
	afx_msg void OnBnClickedDltoggle();
protected:
	int DLCheck;
	unsigned short DLList[IGCSHIPMAXPARTS];
	void BuildDL(void);
	void SaveDL(void);
public:
	afx_msg void OnLbnSelchangePartlist();
};
