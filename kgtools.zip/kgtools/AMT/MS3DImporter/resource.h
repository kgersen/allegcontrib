//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by msPlugIn.rc
//
#define IDD_OPTIONS                     2000
#define IDC_BTMESHES                    2000
#define IDC_BTMATERIALS                 2001
#define IDC_BTBONES                     2002
#define IDD_MESSAGE                     2002
#define IDC_CVHTOO                      2002
#define IDC_BTKEYFRAMES                 2003
#define IDC_CVHTOO2                     2003
#define IDC_BMPOVER                     2003
#define IDC_FILENAME                    2004
#define IDC_BTBROWSE                    2005
#define IDC_BTNOTRANSPARENCY            2007
#define IDC_PROGRESS                    2007
#define IDC_STMESSAGE                   2008
#define IDC_MSGBOX                      2011
#define IDS_ERROR_OPENING_FILE_P        5000
#define IDS_WARNING_MODEL_DELETE        5001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2003
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         2012
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
