#include "..\..\..\aa\amt\mdlfile.h"

// save to .mdl binary format
bool CMDLFile::SaveToFile(CString sPath)
{
	return false;
}
