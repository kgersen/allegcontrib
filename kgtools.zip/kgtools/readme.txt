kgtools
-------

"old" KGJV's tools for Allegiance:


AGM        - VS.Net 2003 C++ solution                       - Allegiance Game Manager exe
AGMLib     - VS.Net 2003 C++ project (part of AGM Solution) - AGM library to get an interface to a running Allegiance Server
AGMTestLib - VS.Net 2003 C# project (part of AGM Solution)  - unfinished AGM port to C#

AME        - VS.Net 2003 C++ solution                       - Allegiance Map Editor (read/write .igc map files)
AMT        - VS.Net 2003 C++ solution                       - Allegiance Modeling Tool (Milkshape 3D plugins)
ICE        - VS.Net 2003 C++ solution                       - IGC Core Editor (read/write .igc core files)
MDLView    - VS.Net 2003 C#  solution                       - 3D MDL models viewer

Required external libs:

FreeImage  - http://freeimage.sourceforge.net/              - version 2.5.2 was used
